/**
 * 错误信息监听
 * clients api获取当前页面可执行的上下文，如window或worker
 * 通过postMessage将错误信息传送给window以便需要收集前端错误的系统
**/
self.addEventListener('error', function (e) {
  self.clients.matchAll()
    .then(function (clients) {
      if (clients && clients.length) {
        clients[0].postMessage({
          type: 'error',
          msg: e.message || null,
          stack: e.error ? e.error.stack : null
        });
      }
    });
});
self.addEventListener('unhandledrejection', function (e) {
  self.clients.matchAll()
    .then(function (clients) {
      if (clients && clients.length) {
        clients[0].postMessage({
          type: 'unhandledrejection',
          msg: e.reason ? e.reason.message : null,
          stack: e.reason ? e.reason.stack : null
        });
      }
    });
});

// 这里需要捕获错误，避免serviceWorker注册失败
try {
  /**
   * workbox引入
   * skipWaiting可防止出现等待情况，这意味着serviceWorker在安装完后立即激活，即在serviceWorker更新时候无需等待上一个serviceWorker释放进程
   * 当多个serviceWorker存在的时候，clientsClaim使当前的serviceWorker占用��活状态（一般需要用skipWaiting联用，以确保当前不在等待）
  **/
  importScripts('https://mimg.127.net/lib/workbox/4.3.1/workbox-sw.js');
  workbox.setConfig({
    debug: false,
    modulePathPrefix: 'https://mimg.127.net/lib/workbox/4.3.1/'
  });
  workbox.core.skipWaiting();
  workbox.core.clientsClaim();

  /**
   * cacheStorage
   * cache目前提供3中缓存策略
   *   NetworkFirst，网络优先，当网络可用的时候读取网络，其缓存一般用于offline状态
   *   CacheFirst，缓存优先，优先读取缓存，其更新方式为更新缓存版本
   *   StaleWhileRevalidate，如果有可用的缓存版本，则使用该版本，但下次会获取更新，一般用于频繁更新但非必需的资源，譬如一些预览图片
  **/
  var cacheStorageConfig;
  cacheStorageConfig = [
    {
      // CacheFirst 缓存优先
      // 优先读取缓存，其更新方式为更新缓存版本
      type: 'CacheFirst',

      // 匹配缓存路由
      route: new RegExp('https://[^.]+\.music\.126\.net/(web|style)/'),

      // 缓存名称，可用于缓存版本管理
      name: 'freemail-login-pc:image-v231115',

      // 最大缓存数量，用于可用配额管理
      max: 30
    },
    {
      // CacheFirst 缓存优先
      // 优先读取缓存，其更新方式为更新缓存版本
      type: 'CacheFirst',

      // 匹配缓存路由
      route: new RegExp('https://onegoods\.nosdn\.127\.net/resupload/|https://mail-online\.nosdn\.127\.net/|https://mail-activity\.nosdn\.127\.net/'),

      // 缓存名称，可用于缓存版本管理
      name: 'freemail-login-pc:image-v231115',

      // 最大缓存数量，用于可用配额管理
      max: 30
    },
    {
      // StaleWhileRevalidate 网络优先
      // 如果有可用的缓存版本，则使用该版本，但下次会获取更新
      type: 'StaleWhileRevalidate',

      // 匹配缓存路由（也可使用函数形式）
      route: new RegExp('https://mimg\.127\.net/'),

      // 缓存名称，可用于缓存版本管理
      name: 'freemail-login-pc:static-v231115',

      // 最大缓存数量，用于可用配额管理
      max: 50
    }
  ];
  if (cacheStorageConfig && Array.isArray(cacheStorageConfig) && cacheStorageConfig.length) {
    cacheStorageConfig.forEach(function (cacheConfig) {
      switch (cacheConfig.type) {
        case 'NetworkFirst':
          workbox.routing.registerRoute(
            cacheConfig.route,
            new workbox.strategies.NetworkFirst({
              cacheName: cacheConfig.name,
              plugins: [
                new workbox.expiration.Plugin({
                  maxEntries: cacheConfig.max || 30
                })
              ]
            })
          );
          break;

        case 'CacheFirst':
          workbox.routing.registerRoute(
            cacheConfig.route,
            new workbox.strategies.CacheFirst({
              cacheName: cacheConfig.name,
              plugins: [
                new workbox.cacheableResponse.Plugin({
                  statuses: [0, 200]
                }),
                new workbox.expiration.Plugin({
                  maxEntries: cacheConfig.max || 30
                })
              ]
            })
          );
          break;
        case 'StaleWhileRevalidate':
          workbox.routing.registerRoute(
            cacheConfig.route,
            new workbox.strategies.StaleWhileRevalidate({
              cacheName: cacheConfig.name,
              plugins: [
                new workbox.expiration.Plugin({
                  maxEntries: cacheConfig.max || 30
                })
              ]
            })
          );
          break;
        default:
          break;
      }
    });
  }

  /**
   * Service Worker激活事件
   * 在激��事件中清除非当前版本的缓存避免用户存储空间急剧膨胀
  **/
  this.addEventListener('activate', function (event) {
    var SW_CACHE_NAME = (cacheStorageConfig || []).map(function (item) {
      return item.name;
    });
    event.waitUntil(caches.keys().then(function (cacheNames) {
      return Promise.all(cacheNames.map(function (cacheName) {
        if (SW_CACHE_NAME.indexOf(cacheName) === -1) {
          return caches.delete(cacheName);
        }
      }));
    }));
  });
} catch (error) {
  console.error('workbox error', error);
}

/**
 * 备用资源策略
 */
var fallback;
fallback = {"enable":true,"rules":[{"route":"/^https?:\\/\\/mimg.127.net\\/(.*)/","fallback":"https://mail.163.com/mimg127/$1"},{"route":"/^https?:\\/\\/hwmimg.127.net\\/(.*)/","fallback":"https://mail.163.com/mimg127/$1"}]};
if (fallback && fallback.enable) {
  self.addEventListener('fetch', function (event) {
    // 如果请求在rulse中匹配，且请求失败，则使用备用资源
    var url = event.request.url;
    var rule = fallback.rules.find(function (item) {
      if (typeof item.route === 'string') {
        item.route = new RegExp(item.route.replace(/^\/|\/$/g, ''));
      }
      return item.route.test(url);
    });
    // console.log('fallback', rule, url);
    if (rule) {
      // 请求失败时使用备用资源
      event.respondWith(
        fetch(event.request).catch(function () {
          if (typeof rule.route === 'string') {
            rule.route = new RegExp(rule.route.replace(/^\/|\/$/g, ''));
          }
          const fallback = url.replace(rule.route, rule.fallback);

          // 发送通知
          self.clients.matchAll()
            .then(function (clients) {
              if (clients && clients.length) {
                clients[0].postMessage({
                  type: 'fallback',
                  url,
                  fallback,
                });
              }
            });

          return fetch(fallback);
        })
      );
      // 直接替换
      // event.respondWith(
      //     fetch(url.replace(rule.route, rule.fallback))
      // );
    }
  });
};

self.addEventListener('push', function (event) {
  const payload = event.data ? event.data.json() : null;
  if (!payload) {
    return;
  }

  // const { uid, mid } = payload;
  const { uid, msgGroup, msgType, message, title, description } = payload;
  // const body = JSON.parse(message.payload.body);
  // const mid = [body.MSID, body.Mid].join(':');

  if (msgGroup !== 'wpmail' || msgType !== 1) {
    return;
  }

  const domain = uid.split('@')[1];
  const loginUrl = `https://${domain.indexOf('vip') === 0 ? 'vipmail.163.com' : 'email.163.com'}/?user=${uid}&utm_source=webpush`;

  event.waitUntil(
    self.clients.matchAll({ type: 'window' }).then(function (clients) {
      for (const client of clients) {
        const url = new URL(client.url);
        if (url.hostname.match(new RegExp(`.${domain}$`)) && url.searchParams.has('sid')) {
          const sid = url.searchParams.get('sid');
          fetch(`/js6/s?sid=${sid}&func=user:getAttrs`, {
            "headers": {
              "accept": "application/json",
              "content-type": "application/x-www-form-urlencoded",
            },
            "body": "var=%3C%3Fxml%20version%3D%221.0%22%3F%3E%3Cobject%3E%3Carray%20name%3D%22attrIds%22%3E%3Cstring%3Eemail%3C%2Fstring%3E%3Cstring%3Eprimary_email%3C%2Fstring%3E%3Cstring%3Edn_email%3C%2Fstring%3E%3C%2Farray%3E%3Cstring%20name%3D%22mrcid%22%3Eb8c80b981cd3b26dc011c631132acc39_v1%3C%2Fstring%3E%3C%2Fobject%3E",
            "method": "POST",
          }).then(response => response.text()).then(data => {
            if (data.indexOf('S_OK') > -1 && data.indexOf(`>${uid}<`) > -1) {
              // 当前账号不做处理
            } else {
              show(loginUrl);
            }
          }).catch(error => {
            show(loginUrl);
          });
          return;
        }
      }
      show(loginUrl);
    })
  );

  function show(url) {
    event.waitUntil(
      self.registration.showNotification(title, {
        body: description,
        data: { url }
      })
    );
  }
});

self.addEventListener('notificationclick', function (event) {
  event.notification.close();
  const { url } = event.notification.data;
  self.clients.openWindow(url);
});